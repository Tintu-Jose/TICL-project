package com.ust.sevice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.dao.EmployeeDao;
import com.ust.model.Employee;

@Service
public class EmpServiceImpl implements IEmpService{

	@Autowired
	EmployeeDao edao;//has-relation
	
	@Override
	public Integer addEmployee(Employee e) {
		edao.save(e); //this is Jps respository method to store in the database.
		return e.getEmpid();
	}

	@Override
	public void updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		edao.save(e);
	}

	@Override
	public boolean isPresent(int id) {	  
		return edao.existsById(id);
	}

	@Override
	public Optional<Employee> getEmployeeById(int id) {
		return edao.findById(id);
	}

	@Override
	public void deleteById(int id) {
		edao.deleteById(id);
	}

	@Override
	public List<Employee> listAllEmployee() {
		return edao.findAll();
	}

	

}
