package com.ust.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="empp")
public class Employee {
	
	@Id
	@Column(name="empno")
	private Integer empid;
	
	@Column(name="ecode",length=20)
	private String empCode;
	
	@Column(name="ename",length=20)
	private String empName;
	
	@Column(name="edesignation",length=20)
	private String empDesignation;
	
	@Column(name="edepartment",length=20)
	private String empDepartment;
	
	@Column(name="eaddress",length=20)
	private String empAddress;
	
	
}
